
namespace BOL;


public class User
    {
        public int UserId{get;set;}
        public string UserName{get;set;}
        public string Email{get;set;}
        public string Password{get;set;}

        public User(int UserId,string UserName,string Email,string Password){
            this.UserId=UserId;
            this.UserName=UserName;
            this.Email=Email;
            this.Password=Password;
        }
            public User(){
            this.UserId=UserId;
            this.UserName=UserName;
            this.Email=Email;
            this.Password=Password;
        }

    public List<User> getAll()
    {
        throw new NotImplementedException();
    }
}