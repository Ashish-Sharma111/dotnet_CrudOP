using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using CrudOp.Models;
using BLL;
using BOL;

namespace CrudOp.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }
  [HttpGet]
     public IActionResult Register()
    {
        return View();
    }
    
    [HttpPost]
     public IActionResult Register(int UserId,string Username,string Email,string Password,string Confirmpass){
        User ue=new User(UserId,Username,Email,Password);
        BusinessLayer.insert(ue);
        return View();
    }


    [HttpGet]
     public IActionResult Login()
    {  
        Console.WriteLine("Invoking Home Controller Login method. ");
        return View();
    }


  [HttpPost]
    public IActionResult Login(string email,string password)
    {
        Console.WriteLine("Validating user Credentials...");
        Console.WriteLine(email+" "+password);

        if (email=="tina@gmail.com" && password=="tina"){
            Console.WriteLine("Valid user");
            Console.WriteLine("Redirectring to welcome...");
            return RedirectToAction("Welcome");
        }
   
        return View();
    }

   public IActionResult Welcome(){
         Console.WriteLine("Invoking Home Controller Welcome  method. ");
       
        return View();
    }



  
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
