﻿namespace DAL;
using MySql.Data.MySqlClient;
public class Connection
{
 private static MySqlConnection connection=null;

 public static MySqlConnection GetConnection(){
    if (connection==null){
        connection=new MySqlConnection();
        connection.ConnectionString="server=192.168.10.150;port=3306;user=dac5;password=welcome;database=dac5"; 
    }
    return connection;   
 }
}
