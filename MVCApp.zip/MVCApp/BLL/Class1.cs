﻿using BOL;
using DAL;
using MySql.Data.MySqlClient;
namespace BLL;

public class BusinessLayer
{
    static MySqlConnection connection=Connection.GetConnection();
    public static void insert(User ue)
    {
     string querry="insert into User values(@UserId,@UserName,@Email,@Password)";
     connection.Open();
     MySqlCommand command=new MySqlCommand(querry,connection);
     command.Parameters.AddWithValue("@UserId",ue.UserId);
     command.Parameters.AddWithValue("@UserName",ue.UserName);
     command.Parameters.AddWithValue("@Email",ue.Email);
     command.Parameters.AddWithValue("@Password",ue.Password);
     command.ExecuteNonQuery();
     connection.Close();

    }
}
